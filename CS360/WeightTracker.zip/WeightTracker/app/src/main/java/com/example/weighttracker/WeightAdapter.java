package com.example.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {
    private List<WeightEntry> weightList;

    public WeightAdapter(List<WeightEntry> weightList) {
        this.weightList = weightList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView, weightTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.textDate);
            weightTextView = itemView.findViewById(R.id.textWeight);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight_entry, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = weightList.get(position);
        holder.dateTextView.setText(entry.getDate());
        holder.weightTextView.setText(entry.getWeight());
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }
}
