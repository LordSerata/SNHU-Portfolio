package com.example.weighttracker;

public class WeightEntry {
    private String date;
    private String weight;

    public WeightEntry(String date, String weight) {
        this.date = date;
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public String getWeight() {
        return weight;
    }
}
